// ✅ Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyANsSQfjqxE6NOKnHTdcmwj2DH35Zv_kA8",
  authDomain: "learningwithearning-a033f.firebaseapp.com",
  projectId: "learningwithearning-a033f",
  storageBucket: "learningwithearning-a033f.appspot.com",
  messagingSenderId: "401129925601",
  appId: "1:401129925601:web:4cdc974c40850072f400a0"
};

// ✅ Initialize Firebase
firebase.initializeApp(firebaseConfig);

// ✅ Wait until DOM is ready (Important for reCAPTCHA)
document.addEventListener("DOMContentLoaded", function () {
  // ✅ Setup reCAPTCHA after page loads
  window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
    size: 'normal',
    callback: function(response) {
      console.log("✅ reCAPTCHA solved");
    }
  });

  // ✅ Render reCAPTCHA widget
  window.recaptchaVerifier.render()
    .then(function(widgetId) {
      console.log("✅ reCAPTCHA rendered, widget ID:", widgetId);
    })
    .catch(function(error) {
      console.error("❌ reCAPTCHA render error:", error);
    });
});

// ✅ Send OTP Function
function sendOTP() {
  let phoneNumber = document.getElementById("phoneNumber").value.trim();

  if (!phoneNumber.startsWith("+")) {
    document.getElementById("result").innerText = "❌ Please include country code, e.g. +91...";
    return;
  }

  firebase.auth().signInWithPhoneNumber(phoneNumber, window.recaptchaVerifier)
    .then(function (confirmationResult) {
      window.confirmationResult = confirmationResult;
      document.getElementById("result").innerText = "📩 OTP Sent!";
      console.log("✅ OTP sent to", phoneNumber);
    }).catch(function (error) {
      document.getElementById("result").innerText = "❌ Error: " + error.message;
      console.error("❌ OTP Error:", error);
    });
}

// ✅ Verify OTP Function
function verifyOTP() {
  let code = document.getElementById("otp").value;
  if (!window.confirmationResult) {
    document.getElementById("result").innerText = "❌ Please send OTP first!";
    return;
  }
  window.confirmationResult.confirm(code)
    .then(function (result) {
      document.getElementById("result").innerText = "✅ Number Verified Successfully!";
      console.log("✅ User verified:", result.user.phoneNumber);
    }).catch(function (error) {
      document.getElementById("result").innerText = "❌ Invalid OTP!";
      console.error("❌ Verify OTP Error:", error);
    });
}
