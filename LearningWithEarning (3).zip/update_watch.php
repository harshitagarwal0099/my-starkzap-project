<?php
session_start();
require_once 'db.php';

if(!isset($_SESSION['user_id'])) {
    echo json_encode(['status'=>'error','msg'=>'Not logged in']);
    exit;
}

$uid = $_SESSION['user_id'];
$watch_time = isset($_POST['minutes']) ? (int)$_POST['minutes'] : 0;

// Update total_watching_time
$stmt = $conn->prepare("UPDATE users SET total_watching_time = total_watching_time + ? WHERE id=?");
$stmt->bind_param("ii", $watch_time, $uid);
if($stmt->execute()){
    echo json_encode(['status'=>'success']);
} else {
    echo json_encode(['status'=>'error','msg'=>$stmt->error]);
}
$stmt->close();
$conn->close();
?>
