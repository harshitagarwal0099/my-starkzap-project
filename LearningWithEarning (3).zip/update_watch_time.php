<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'msg' => 'Not logged in']);
    exit;
}

$uid = $_SESSION['user_id'];

// action parameter: 'add' (default) या 'reset'
$action = isset($_POST['action']) ? $_POST['action'] : 'add';

if ($action === 'reset') {
    // Reset total_watching_time for this user
    $stmt = $conn->prepare("UPDATE users SET total_watching_time = 0 WHERE id = ?");
    $stmt->bind_param("i", $uid);
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'msg' => 'reset']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => $stmt->error]);
    }
    $stmt->close();
    $conn->close();
    exit;
}

// Default: add minutes (action = add)
$minutes = isset($_POST['minutes']) ? (int)$_POST['minutes'] : 0;
if ($minutes <= 0) {
    echo json_encode(['status' => 'error', 'msg' => 'Invalid minutes']);
    exit;
}

$stmt = $conn->prepare("UPDATE users SET total_watching_time = total_watching_time + ? WHERE id = ?");
$stmt->bind_param("ii", $minutes, $uid);
if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'msg' => 'added']);
} else {
    echo json_encode(['status' => 'error', 'msg' => $stmt->error]);
}
$stmt->close();
$conn->close();
?>
