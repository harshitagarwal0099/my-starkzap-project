<?php
// db.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$servername = "sql104.infinityfree.com";
$username   = "if0_39930609";
$password   = "2aGnkwXuzV";
$dbname     = "if0_39930609_LearningWithEarning";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}
?>
