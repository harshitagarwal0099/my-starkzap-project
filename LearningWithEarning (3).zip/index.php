<?php
session_start();
require_once 'db.php';

// 🟢 Handle Withdraw Request (only if user is logged in)
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['upi']) &&
    isset($_POST['amount']) &&
    !isset($_POST['signup']) &&
    !isset($_POST['login'])
) {
    if (!isset($_SESSION['user_id'])) {
        echo "error: not logged in";
        exit;
    }

    $upi = trim($_POST['upi']);
    $amount = floatval($_POST['amount']);
    $uid = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE users SET upi_id=?, withdraw_request_amount=?, has_withdraw_request=1 WHERE id=?");
    $stmt->bind_param("sdi", $upi, $amount, $uid);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    exit;
}

// ✅ AJAX request for UPI update (only logged-in users)
if (
    isset($_POST['upi']) &&
    isset($_SESSION['user_id']) &&
    !isset($_POST['signup']) &&
    !isset($_POST['login']) &&
    !isset($_POST['amount'])
) {
    $upi = trim($_POST['upi']);
    $stmt = $conn->prepare("UPDATE users SET upi_id=? WHERE id=?");
    $stmt->bind_param("si", $upi, $_SESSION['user_id']);
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }
    $stmt->close();
    $conn->close();
    exit;
}

// ✅ Update total watching time (AJAX from nextpage.html)
if (isset($_POST['minutes']) && isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $minutes = (int)$_POST['minutes'];

    $stmt = $conn->prepare("UPDATE users SET total_watching_time = total_watching_time + ? WHERE id=?");
    $stmt->bind_param("ii", $minutes, $uid);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'msg' => $stmt->error]);
    }

    $stmt->close();
    $conn->close();
    exit;
}

$msg = "";

// ✅ Signup
if (isset($_POST['signup'])) {
    $firstname = trim($_POST['firstname']);
    $lastname  = trim($_POST['lastname']);
    $email     = trim($_POST['email']);
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $upi       = isset($_POST['upi']) ? trim($_POST['upi']) : null;

    $stmt = $conn->prepare("INSERT INTO users (firstname, lastname, email, password, upi_id, balance, total_watching_time, has_withdraw_request, withdraw_request_amount) VALUES (?, ?, ?, ?, ?, 0, 0, 0, 0)");
    $stmt->bind_param("sssss", $firstname, $lastname, $email, $password, $upi);
    if ($stmt->execute()) {
        $msg = "✅ Signup successful! You can now login.";
    } else {
        $msg = "❌ Error: " . $stmt->error;
    }
    $stmt->close();
}

// ✅ Login
if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, firstname, password FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows == 1) {
        $row = $res->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user'] = $row['firstname'];
            $_SESSION['email'] = $email;
            $msg = "✅ Login successful! Welcome, " . $row['firstname'];
            header("Refresh:2; url=nextpage.html");
        } else {
            $msg = "❌ Invalid password.";
        }
    } else {
        $msg = "❌ No account found with this email.";
    }
    $stmt->close();
}

// ✅ Logout
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ✅ UPI update (manual form)
if (isset($_POST['update_upi']) && isset($_SESSION['user_id'])) {
    $upi = trim($_POST['upi']);
    $stmt = $conn->prepare("UPDATE users SET upi_id=? WHERE id=?");
    $stmt->bind_param("si", $upi, $_SESSION['user_id']);
    if ($stmt->execute()) {
        $msg = "✅ UPI updated.";
    } else {
        $msg = "❌ Error updating UPI.";
    }
    $stmt->close();
}

// ✅ Hourly earning addition
if (isset($_POST['add_hourly_earning']) && isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $earning_per_hour = 10;

    $stmt = $conn->prepare("SELECT balance FROM users WHERE id=?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();

    $new_balance = $user['balance'] + $earning_per_hour;

    $stmt = $conn->prepare("UPDATE users SET balance=? WHERE id=?");
    $stmt->bind_param("di", $new_balance, $uid);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['status' => 'success', 'new_balance' => $new_balance]);
    exit;
}

// ✅ Withdrawal Request (Button)
if (isset($_POST['withdraw_request']) && isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];

    $stmt = $conn->prepare("SELECT balance, has_withdraw_request FROM users WHERE id=?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();

    if ($user['has_withdraw_request'] == 1) {
        $msg = "⚠️ You already have a pending withdrawal request.";
    } elseif ($user['balance'] <= 0) {
        $msg = "❌ You must have a positive balance to request withdrawal.";
    } else {
        $amount = $user['balance'];
        $stmt = $conn->prepare("UPDATE users SET has_withdraw_request=1, withdraw_request_amount=? WHERE id=?");
        $stmt->bind_param("di", $amount, $uid);
        if ($stmt->execute()) {
            $msg = "✅ Withdrawal request submitted successfully!";
        } else {
            $msg = "❌ Error submitting request: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>LearningWithEarning</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>🚀 Our Website is Live</h1>
    <h1>#LearningWithEarning</h1>

    <div class="container">
        <?php if(isset($msg)) echo "<div class='message'>$msg</div>"; ?>

        <?php if(!isset($_SESSION['user'])): ?>
        <!-- ✅ Signup Form -->
        <h2>Signup</h2>
        <form method="post">
            <input type="text" name="firstname" placeholder="First Name" required><br>
            <input type="text" name="lastname" placeholder="Last Name" required><br>
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="text" name="upi" placeholder="UPI ID (optional)"><br>
            <button type="submit" name="signup">Signup</button>
        </form>

        <hr>

        <!-- ✅ Login Form -->
        <h2>Login</h2>
        <form method="post">
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit" name="login">Login</button>
        </form>

        <?php else: 
            $uid = $_SESSION['user_id'];
            $stmt = $conn->prepare("SELECT email, upi_id, balance, total_watching_time, has_withdraw_request FROM users WHERE id=?");
            $stmt->bind_param("i", $uid);
            $stmt->execute();
            $res = $stmt->get_result();
            $userRow = $res->fetch_assoc();
            $stmt->close();
        ?>
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user']); ?> 🎉</h2>
        <p>⏳ Redirecting to video page in 5 seconds...</p>

        <form method="post">
            <button type="submit" name="logout">Logout</button>
        </form>

        <script>
        setTimeout(() => {
            window.location.href = "nextpage.html";
        }, 5000);
        </script>

        <?php endif; ?>
    </div>
</body>
</html>
<?php $conn->close(); ?>
